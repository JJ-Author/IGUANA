java $2 -cp "lib/*" org.aksw.iguana.benchmark.Main $1 $3
